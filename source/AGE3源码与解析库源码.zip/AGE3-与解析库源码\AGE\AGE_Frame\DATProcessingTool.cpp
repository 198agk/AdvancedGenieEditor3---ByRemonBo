#include "Common.h"
#include "../AGE_Frame.h"

#include <wx/sstream.h>
#include <wx/file.h>
#include <boost/json.hpp>
#include <sstream>

const wxString DATProcessingToolHandler::DAT_PROCESSING_TOOL_CONFIG_PATH = "./DATProcessingToolConfig.json";

namespace json = boost::json;

DATProcessingToolConfig tag_invoke(boost::json::value_to_tag<DATProcessingToolConfig>, boost::json::value const& jv)
{
    auto const& obj = jv.as_object();
    return DATProcessingToolConfig{
        json::value_to<std::string>(obj.at("tool_location")),
        json::value_to<std::vector<std::string>>(obj.at("arguments")),
        json::value_to<std::string>(obj.at("min_dat_version")),
        json::value_to<std::string>(obj.at("expected_dat_save_folder"))
    };
}

bool DATProcessingToolConfig::IsDatFileInsideExpectedFolder(const wxString datFilePath) const
{
    wxFileName fileFN(datFilePath);
    wxFileName parentFN = wxFileName::DirName(expected_dat_save_folder);

    fileFN.Normalize(wxPATH_NORM_ABSOLUTE | wxPATH_NORM_DOTS);
    parentFN.Normalize(wxPATH_NORM_ABSOLUTE | wxPATH_NORM_DOTS);

    // Check the drive
    if (!fileFN.GetVolume().IsSameAs(parentFN.GetVolume(), false))
        return false;

    wxArrayString fileDirs = fileFN.GetDirs();
    wxArrayString parentDirs = parentFN.GetDirs();

    // Parent is deeper that the file
    if (parentDirs.size() > fileDirs.size())
        return false;

    for (size_t i = 0; i < parentDirs.size(); ++i)
    {
        if (!fileDirs[i].IsSameAs(parentDirs[i], false))
            return false;
    }

    return true;
}

bool DATProcessingToolConfig::IsDatVersionValid(const std::string datVersionStr) const
{
    try
    {
        float minVersion = std::stof(min_dat_version);

        std::stringstream ss(datVersionStr);
        std::string prefix;
        float currentFileVersion;
        ss >> prefix >> currentFileVersion;

        return minVersion <= currentFileVersion;

    }
    catch (std::exception const& e)
    {
        wxLogDebug("Error: %s", e.what());
        return false;
    }
}

DATProcessingToolLog from_json_tool_log(json::value const& jv) {
    auto const& obj = jv.as_object();
    return DATProcessingToolLog{
        json::value_to<std::string>(obj.at("severity")),
        json::value_to<std::string>(obj.at("message"))
    };
}

bool AGE_Frame::TryLoadDATProcessingConfig(DATProcessingToolConfig& config)
{
    try
    {
        // No configuration file found
        if (!wxFileExists(DATProcessingToolHandler::DAT_PROCESSING_TOOL_CONFIG_PATH))
        {
            return false;
        }

        wxFile configFile(DATProcessingToolHandler::DAT_PROCESSING_TOOL_CONFIG_PATH);

        wxString wxContent;
        if (!configFile.ReadAll(&wxContent))
        {
            return false;
        }

        const std::string utf8(wxContent.utf8_str());
        json::value jsonValue = json::parse(utf8);
        config = boost::json::value_to<DATProcessingToolConfig>(jsonValue);

        // No executable found
        if (!wxFileExists(config.tool_location))
        {
            return false;
        }
    }
    catch (boost::system::system_error const&)
    {
        wxLogWarning("An issue has been encountered when trying to parse the DAT Processing Tool configuration file at %s",
            DATProcessingToolHandler::DAT_PROCESSING_TOOL_CONFIG_PATH);
        return false;
    }
    catch (std::exception const& e)
    {
        wxLogDebug("Error: %s", e.what());
        return false;
    }

    return true;
}

void AGE_Frame::RunDATProcessingTool(wxString datFilePath)
{
    // Clear status text
    SetStatusText("", DATProcessingToolStatusBarPos);

    // Clean up any previous process
    if (IsDatProcessingToolRunning())
    {
        InterruptCurrentDATProcessing();
    }

    // Try to find configuration file and silently fail if it does not exist
    DATProcessingToolConfig config;
    if (!TryLoadDATProcessingConfig(config))
    {
        return;
    }

    // Check if the DAT file version is valid if not silently fail
    if (!config.IsDatVersionValid(dataset->FileVersion))
    {
        return;
    }

    // Check current dat path is valid if not silently fail
    if (!config.IsDatFileInsideExpectedFolder(datFilePath))
    {
        return;
    }

    // Create process handler
    m_datProcessingToolProc = std::make_unique<DATProcessingToolHandler>(this);

    // Build command
    wxArrayString command;
    command.push_back(config.tool_location);

    for (auto& arg : config.arguments)
    {
        if (arg == "$age_dat_path$")
        {
            command.push_back(datFilePath);
        }
        else
        {
            command.push_back(arg);
        }
    }

    // Build argv array for wxExecute
    std::vector<const wxChar*> argv;
    argv.reserve(command.size() + 1);
    for (auto& s : command)
        argv.push_back(s.c_str());
    argv.push_back(nullptr);

    // Execute process
    m_datProcessingToolPid = wxExecute(argv.data(), wxEXEC_ASYNC, m_datProcessingToolProc.get());

    if (m_datProcessingToolPid == 0)
    {
        // Something went wrong while trying to execute the process
        m_datProcessingToolProc.reset();

        SetStatusText("Could not start DAT Processing Tool", DATProcessingToolStatusBarPos);

        return;
    }

    SetStatusText("Running DAT Processing Tool...", DATProcessingToolStatusBarPos);
}

void AGE_Frame::OnProcessTerminated(wxProcessEvent& event)
{
    long pid = event.GetPid();
    int exitCode = event.GetExitCode();

    if (pid != m_datProcessingToolPid)
    {
        return;
    }

    if (exitCode == 0)
    {
        SetStatusText("DAT Processing Successful", DATProcessingToolStatusBarPos);
    }
    else
    {
        SetStatusText("DAT Processing Failed", DATProcessingToolStatusBarPos);
    }
    if (m_datProcessingToolProc != nullptr)
    {
        wxString err;
        if (wxInputStream* se = m_datProcessingToolProc->GetErrorStream())
        {
            wxStringOutputStream ses(&err);
            se->Read(ses);
        }

        // Parse and display errors
        if (!err.empty())
        {
            ParseAndDisplayDatProcessingToolOutput(err);
        }
    }

    // Reset process variables
    m_datProcessingToolProc.reset();
    m_datProcessingToolPid = 0;

}

void AGE_Frame::InterruptCurrentDATProcessing()
{
    if (!m_datProcessingToolProc)
    {
        return;
    }

    wxKillError err;
    wxKill(m_datProcessingToolPid, wxSIGKILL, &err);

    if (err != wxKILL_OK)
    {
        wxLogWarning("Failed to send kill signal to process with pid=%ld (err=%d)", m_datProcessingToolPid, static_cast<int>(err));
        return;
    }
    // From wxWidgets doc: should be called by the parent if it's deleted before the process it started terminates
    m_datProcessingToolProc->Detach();

    m_datProcessingToolProc.reset();
    m_datProcessingToolPid = 0;
}

void AGE_Frame::ParseAndDisplayDatProcessingToolOutput(wxString json) const
{
    try
    {
        std::string utf8(json.utf8_str());

        json::value jsonValue = json::parse(utf8);

        DATProcessingToolLog log = from_json_tool_log(jsonValue);

        auto severity = wxString::FromUTF8(log.severity);
        auto message = wxString::FromUTF8(log.message);

        wxMessageBox(message, "DAT Processing Tool " + severity);
    }
    catch (boost::system::system_error const& e)
    {
        wxLogDebug("DAT Processing Tool logs parse error: %s", e.what());
    }
    catch (std::exception const& e)
    {
        wxLogDebug("Error: %s", e.what());
    }
}
