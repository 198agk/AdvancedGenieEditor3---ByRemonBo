#pragma once
#include <wx/app.h>

class AGE : public wxApp
{
    virtual bool OnInit() override;
    void OutputLastDATVersion();
};

DECLARE_APP(AGE)
