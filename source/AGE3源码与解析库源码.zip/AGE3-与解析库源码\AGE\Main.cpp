#include "Common.h"
#include "BaseMainFrame.h"
#include "Main.h"
#include "genie/Types.h"

#include <fstream>

IMPLEMENT_APP(AGE)

BaseMainFrame* BaseMainFrame::openEditors[4]{ 0 };
Copies BaseMainFrame::copies;

bool AGE::OnInit()
{
    SetVendorName("Tapsa");
    SetAppName("AdvancedGenieEditor3");
    SetAppDisplayName("Advanced Genie Editor");
    wxImage::AddHandler(new wxPNGHandler);
    wxImage::AddHandler(new wxTGAHandler);

    wxToolTip::SetDelay(200);
    wxToolTip::SetAutoPop(32700);
    wxToolTip::SetReshow(1);

    wxString cmd1 = (wxApp::argc > 1) ? wxApp::argv[1] : "";

    if (cmd1 == "--latestSupportedDATVersion")
    {
        OutputLastDATVersion();

        // Returning false to terminate the process before the GUI (wxWidget) is created.
        return false;
    }

    BaseMainFrame* window = BaseMainFrame::Create(cmd1);
    SetTopWindow(window);
    wxCommandEvent open;
    window->OnOpen(open);

    return true;
}

void AGE::OutputLastDATVersion()
{
    std::ofstream outFile("age_dat_version.txt");
    outFile << genie::GetLastSupportedDatVersion();
    outFile.close();
}
