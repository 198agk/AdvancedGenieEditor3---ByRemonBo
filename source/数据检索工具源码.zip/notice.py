# -*- coding: utf-8 -*-
"""防伪声明弹窗（tkinter 版，给「AGE 数据检索工具」用）。

第一次打开软件弹一次：本软件完全免费且开源，花钱买到的请退款，认准作者 RemonBo。
勾选「本周不再提示」后把日期写进 config.json，7 天内不再弹。
"""
import datetime

TITLE = "防伪声明"
DAYS = 7
CHECK_TEXT = "本周不再提示"
ACK_KEY = "notice_ack"

LINES = [
    "本软件完全免费，也完全开源。作者：RemonBo（署名见窗口标题与「使用说明」）。",
    "如果你是花钱买到的，请立即退款 —— 作者没有、也不会出售这款工具。",
    "任何收费群、代购、二手转卖、加密压缩包、改个名字再发一遍的，都不是作者本人。",
    "唯一的发布渠道是作者自己发出的链接（GitHub：github.com/198agk ／ 爱发电 afdian.com/a/RemonBo ／ B 站 space.bilibili.com/6978282），别的地方拿到的一律存疑。",
    "软件不会要求你付费解锁任何功能，也不会向你索要游戏账号或密码。",
    "觉得有用的话，赞助完全自愿 —— 但永远不需要付费。",
]


def _today():
    return datetime.date.today()


def should_show(cfg, today=None):
    """该不该弹：没记录过、记录坏了、或者上次确认已经超过 DAYS 天。"""
    last = (cfg or {}).get(ACK_KEY)
    if not last:
        return True
    try:
        d = datetime.date.fromisoformat(str(last)[:10])
    except Exception:
        return True
    return ((today or _today()) - d).days >= DAYS


def ack(cfg, when=None):
    """记下「这次确认了」的日期（写进传进来的 dict，由调用方保存）。"""
    cfg[ACK_KEY] = str(when or _today())
    return cfg


def unack(cfg):
    cfg.pop(ACK_KEY, None)
    return cfg


def show_notice(parent, cfg, save_cb=None):
    """弹出声明；返回 True 表示用户点了「我知道了」（勾着勾选框就记日期）。

    parent 是根窗口；save_cb(cfg) 用来把 cfg 落盘（不传就只改内存）。
    """
    import tkinter as tk
    from tkinter import ttk

    win = tk.Toplevel(parent)
    win.title(TITLE)
    win.transient(parent)
    win.resizable(False, False)
    try:
        win.call("tk", "scaling", 1.3)
    except Exception:
        pass

    body = ttk.Frame(win, padding=16)
    body.pack(fill="both", expand=True)

    t = tk.Label(body, text=TITLE, font=("Microsoft YaHei UI", 14, "bold"), anchor="w")
    t.pack(fill="x", pady=(0, 10))
    for line in LINES:
        lab = tk.Label(body, text="· " + line, anchor="w", justify="left", wraplength=620)
        lab.pack(fill="x", pady=1)

    bottom = ttk.Frame(body)
    bottom.pack(fill="x", pady=(16, 0))
    var = tk.BooleanVar(value=True)
    chk = ttk.Checkbutton(bottom, text=CHECK_TEXT, variable=var)
    chk.pack(side="left")
    ttk.Button(bottom, text="我知道了", command=win.destroy).pack(side="right")

    win.update_idletasks()
    try:
        px = parent.winfo_rootx() + max(0, (parent.winfo_width() - win.winfo_width()) // 2)
        py = parent.winfo_rooty() + 80
        win.geometry("+%d+%d" % (px, py))
    except Exception:
        pass
    try:
        win.grab_set()
    except Exception:
        pass
    win.focus_force()
    parent.wait_window(win)

    if var.get():
        ack(cfg)
        if save_cb:
            try:
                save_cb(cfg)
            except Exception:
                pass
    else:
        unack(cfg)
        if save_cb:
            try:
                save_cb(cfg)
            except Exception:
                pass
    return True
